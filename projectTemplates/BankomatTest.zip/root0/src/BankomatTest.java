import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class BankomatTest {
    @Test
    void LogIn() {

        User LogIn= (new Bankomat()).logIn("Sune", "password");
        List<Account> accounts = LogIn.getAccounts();
        assertEquals("Sune", LogIn.getName());
        assertEquals("password", LogIn.getPassword());

        Account Result = accounts.get(0);
        assertEquals("123456", Result.getAccountNumber());
        assertEquals(11, Result.getAccountBalance());

        Account getResult1 = accounts.get(1);
        assertEquals("987654", getResult1.getAccountNumber());
        assertEquals(12, getResult1.getAccountBalance());
        assertEquals(2, accounts.size());

        assertNull((new Bankomat()).logIn("John", "que1122"));
        assertNull((new Bankomat()).logIn("Daniel", "que1122"));


    }
    @Test
    void CheckAccountBalance() {
        Bankomat bankomat = new Bankomat();
        ArrayList<Account> accountList = new ArrayList<>();

        assertEquals(-9999, bankomat.CheckAccountBalance(new User("Mariam", "Ahmed", new ArrayList<>()), "53"));


        accountList.add(new Account("10", 100));

        assertEquals(100, bankomat.CheckAccountBalance(new User("John", "que1122", accountList), "10"));
        assertEquals(-9999, bankomat.CheckAccountBalance(new User("Fatima", "password", accountList), "42"));

    }
    @Test
    void DepositMoney() {
        Bankomat bankomat = new Bankomat();
        Account account = new Account("60", 123);

        Account DepositMoney = bankomat.DepositMoney(account, 1);

        assertSame(account, DepositMoney);
        assertEquals(124, DepositMoney.getAccountBalance());
        assertNotEquals(7, DepositMoney.getAccountBalance());
        assertEquals(124, DepositMoney.getAccountBalance());
    }


    @Test
    void WithdrawMoney() {
        Bankomat bankomat = new Bankomat();
        Account account = new Account("42", 79);

        Account WithdrawMoney = bankomat.WithdrawMoney(account, 100);
        assertSame(account, bankomat.WithdrawMoney(account, 34));
        assertSame(account, bankomat.WithdrawMoney(account, 542));

        assertSame(account, WithdrawMoney);
        assertEquals(45, WithdrawMoney.getAccountBalance());
    }

}