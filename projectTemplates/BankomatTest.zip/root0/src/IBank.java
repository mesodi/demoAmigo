import java.util.List;







    public interface IBank {
        public List<User> getUsers();

    }

