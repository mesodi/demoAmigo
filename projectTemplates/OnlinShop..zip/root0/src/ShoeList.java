import java.util.ArrayList;
import java.util.List;

public class ShoeList {

    static List<String> Skor;
    static {
        Skor = new ArrayList<String>();
        Skor.add("Sneakers         Är 950kr");
        Skor.add("\n platta skor     Är 500kr ");
        Skor.add("\n Stövlar         Är 480kr");
        Skor.add("\n Högklackar skor Är  1100kr");

}

}

