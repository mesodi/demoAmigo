import java.util.ArrayList;
import java.util.List;

public class BagList {


    static List<String> väska;
    static {

        väska = new ArrayList<String>();

        väska.add("gymväskor   Är 750kr");
        väska.add("\n Ryggsäckor  Är 600 ");
        väska.add("\n Skinnväskor Är 1000");
        väska.add("\n Handväskor  Är 450");
        System.out.println("Väskor ");


    }

}
